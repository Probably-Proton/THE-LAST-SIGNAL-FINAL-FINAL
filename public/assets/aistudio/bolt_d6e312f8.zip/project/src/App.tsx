import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  Archive,
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Bell,
  Check,
  ChevronDown,
  Clock3,
  FileText,
  FolderOpen,
  Gauge,
  Headphones,
  LayoutDashboard,
  Lock,
  Map,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Play,
  Radio,
  Search,
  Settings,
  ShieldAlert,
  SlidersHorizontal,
  Sparkles,
  UserRound,
  Users,
  Volume2,
  X,
} from 'lucide-react';
import { evidence, messages, navItems, stages, type EvidenceItem, type Stage } from '@/lib/mockData';

const iconMap = { layout: LayoutDashboard, folder: FolderOpen, file: FileText, map: Map, message: MessageSquare, activity: Activity, bar: BarChart3, users: Users } as const;

type IconName = keyof typeof iconMap;
type RouteView = 'landing' | 'dashboard' | 'investigation' | 'evidence' | 'viewer' | 'map' | 'messages' | 'progress' | 'leaderboard' | 'team' | 'account' | 'admin';

function getRoute(): { view: RouteView; id?: string } {
  const parts = window.location.pathname.split('/').filter(Boolean);
  if (parts[0] === 'evidence' && parts[1]) return { view: 'viewer', id: parts[1] };
  const route = parts[0] as RouteView | undefined;
  const known: RouteView[] = ['dashboard', 'investigation', 'evidence', 'map', 'messages', 'progress', 'leaderboard', 'team', 'account', 'admin'];
  return { view: known.includes(route as RouteView) ? route as RouteView : 'landing' };
}

function navigate(path: string): void {
  window.history.pushState({}, '', path);
  window.dispatchEvent(new PopStateEvent('popstate'));
}

function App() {
  const [route, setRoute] = useState(getRoute);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handlePopState = (): void => setRoute(getRoute());
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const showShell = route.view !== 'landing';
  if (!showShell) return <Landing />;

  return (
    <div className="app-shell">
      <Sidebar current={route.view} mobileOpen={mobileOpen} closeMobile={() => setMobileOpen(false)} />
      <main className="main-content">
        <header className="topbar">
          <button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="breadcrumb"><span>CASE FILE</span><span className="breadcrumb-separator">/</span><strong>{route.view === 'viewer' ? 'EVIDENCE' : route.view.toUpperCase()}</strong></div>
          <div className="topbar-actions">
            <span className="live-status"><span className="live-dot" /> Demo mode</span>
            <button className="icon-button demo-disabled" aria-label="Notifications unavailable in demo mode" disabled title="Notifications are unavailable in demo mode"><Bell size={18} /></button>
            <button className="profile-chip" onClick={() => navigate('/account')}><span className="avatar">JD</span><span className="profile-name">J. Doe</span><ChevronDown size={14} /></button>
          </div>
        </header>
        <div className="page-wrap"><Page route={route} /></div>
      </main>
    </div>
  );
}

function Sidebar({ current, mobileOpen, closeMobile }: { current: RouteView; mobileOpen: boolean; closeMobile: () => void }) {
  return <>
    {mobileOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={closeMobile} />}
    <aside className={`sidebar ${mobileOpen ? 'is-open' : ''}`}>
      <div className="brand-block">
        <div className="brand-mark"><Radio size={18} /></div>
        <div><div className="brand-name">THE LAST SIGNAL</div><div className="brand-kicker">FICTIONAL SCHOOL MYSTERY</div></div>
        <button className="icon-button sidebar-close" onClick={closeMobile} aria-label="Close navigation"><X size={18} /></button>
      </div>
      <div className="case-label"><span className="eyebrow">ACTIVE CASE</span><strong>CASE 07 / ARCHIVE</strong><span className="case-status"><span className="live-dot" /> Investigation open</span></div>
      <nav className="nav-list" aria-label="Primary navigation">
        <div className="nav-section-label">Investigation</div>
        {navItems.map((item) => {
          const Icon = iconMap[item.icon as IconName];
          const active = current === item.path.slice(1) || (current === 'viewer' && item.path === '/evidence');
          return <button key={item.path} className={`nav-item ${active ? 'active' : ''}`} onClick={() => { navigate(item.path); closeMobile(); }}><Icon size={17} strokeWidth={1.8} /><span>{item.label}</span>{item.label === 'Messages' && <span className="nav-badge">2</span>}</button>;
        })}
        <div className="nav-section-label nav-section-lower">Workspace</div>
        <button className={`nav-item ${current === 'account' ? 'active' : ''}`} onClick={() => { navigate('/account'); closeMobile(); }}><UserRound size={17} strokeWidth={1.8} /><span>Account</span></button>
        <button className={`nav-item ${current === 'admin' ? 'active' : ''}`} onClick={() => { navigate('/admin'); closeMobile(); }}><Settings size={17} strokeWidth={1.8} /><span>Admin shell</span><span className="demo-pill">Demo</span></button>
      </nav>
      <div className="sidebar-footer"><div className="sidebar-footer-icon"><ShieldAlert size={17} /></div><div><strong>Need help?</strong><span>Safety &amp; debrief</span></div><ArrowRight size={15} /></div>
    </aside>
  </>;
}

function Page({ route }: { route: { view: RouteView; id?: string } }) {
  switch (route.view) {
    case 'dashboard': return <Dashboard />;
    case 'investigation': return <Investigation />;
    case 'evidence': return <EvidenceRoom />;
    case 'viewer': return <EvidenceViewer id={route.id ?? 'CAS-017'} />;
    case 'map': return <SignalMap />;
    case 'messages': return <Messages />;
    case 'progress': return <Progress />;
    case 'leaderboard': return <Leaderboard />;
    case 'team': return <Team />;
    case 'account': return <Account />;
    case 'admin': return <Admin />;
    default: return <Dashboard />;
  }
}

function Landing() {
  return <div className="landing"><div className="landing-grid" /><div className="landing-card"><div className="landing-topline"><span>LT. ARCHIVE / 07</span><span>DEMO ENVIRONMENT</span></div><div className="landing-emblem"><Radio size={26} /></div><p className="landing-kicker">A FICTIONAL SCHOOL MYSTERY GAME</p><h1>THE LAST<br /><em>SIGNAL</em></h1><p className="landing-copy">Seven stages. Fourteen days. One archive that should have stayed closed.</p><div className="landing-actions"><button className="button button-primary" onClick={() => navigate('/dashboard')}>Preview the archive <ArrowRight size={16} /></button><button className="text-button" onClick={() => navigate('/investigation')}>Read case briefing <ArrowRight size={15} /></button></div><div className="landing-note"><Lock size={14} /> This is an online-only fictional investigation. No real locations or emergency services are involved.</div></div><div className="landing-footer"><span>THE LAST SIGNAL / STUDENT INVESTIGATION SERIES</span><span>V.01 — OCT 2026</span></div></div>;
}

function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action && <div className="header-action">{action}</div>}</div>;
}

function DemoNotice({ children = 'Demo data only — live case rules will appear after the verified backend is connected.' }: { children?: React.ReactNode }) {
  return <div className="demo-notice"><Sparkles size={16} /><span>{children}</span></div>;
}

function Dashboard() {
  return <><PageHeader eyebrow="Monday, 26 October 2026 / 09:14" title="Good morning, investigator." description="The archive is open. Your next signal is waiting." action={<button className="button button-secondary" onClick={() => navigate('/evidence')}><Archive size={16} /> Open evidence room</button>} /><DemoNotice /><div className="dashboard-grid"><section className="feature-card stage-feature"><div className="card-overline"><span>YOUR CURRENT STAGE</span><span className="status-pill available">AVAILABLE</span></div><div className="stage-number">03</div><h2>The witness testimony</h2><p>Read the transcript, study the gaps, and find the location hidden inside the case file.</p><div className="progress-line"><span style={{ width: '64%' }} /></div><div className="feature-meta"><span>64% reviewed</span><span>Window closes in <strong>31:42:18</strong></span></div><button className="button button-primary" onClick={() => navigate('/evidence/CAS-017')}>Continue investigation <ArrowRight size={16} /></button></section><section className="panel time-panel"><div className="panel-heading"><span>DEMO CLOCK</span><Clock3 size={16} /></div><div className="time-display">09:14<span>:36</span></div><div className="time-caption">Preview timestamp / not server time</div><div className="rule" /><div className="mini-stat"><span>CASE WINDOW</span><strong>Stage 3 of 7</strong></div><div className="mini-stat"><span>TIME REMAINING</span><strong className="red-text">31h 42m</strong></div></section><section className="panel message-panel"><div className="panel-heading"><span>LATEST SIGNALS</span><button className="small-link" onClick={() => navigate('/messages')}>View all <ArrowRight size={13} /></button></div>{messages.slice(0, 3).map((message) => <MessageRow key={`${message.sender}-${message.time}`} {...message} />)}</section><section className="panel progress-panel"><div className="panel-heading"><span>CASE PROGRESS</span><button className="small-link" onClick={() => navigate('/progress')}>Details <ArrowRight size={13} /></button></div><div className="big-progress"><strong>2</strong><span>/ 7 stages cleared</span></div><div className="stage-dots">{stages.map((stage) => <span key={stage.number} className={`stage-dot ${stage.state}`} title={stage.title}>{stage.state === 'completed' ? <Check size={11} /> : stage.number}</span>)}</div><div className="progress-foot"><span>Case completion</span><strong>28%</strong></div></section></div><section className="section-block"><div className="section-title"><div><div className="eyebrow">CASE INDEX</div><h2>Investigation at a glance</h2></div><button className="small-link" onClick={() => navigate('/investigation')}>Open case index <ArrowRight size={13} /></button></div><div className="stage-strip">{stages.slice(0, 4).map((stage) => <StageCard key={stage.number} stage={stage} compact />)}</div></section></>;
}

function MessageRow({ sender, time, text, tone }: { sender: string; time: string; text: string; tone: string }) {
  return <div className="message-row"><div className={`message-avatar ${tone}`}>{tone === 'system' ? <Radio size={13} /> : tone === 'director' ? 'D' : '?'}</div><div className="message-body"><div><strong>{sender}</strong><time>{time}</time></div><p>{text}</p></div></div>;
}

function Investigation() {
  return <><PageHeader eyebrow="Archive / Case index" title="The investigation" description="A chronological record of the seven signals. The archive expands as the case unfolds." /><DemoNotice>Story text is sourced from the supplied design document. Unlocks and timestamps are visual placeholders.</DemoNotice><div className="investigation-layout"><section className="timeline">{stages.map((stage) => <StageCard key={stage.number} stage={stage} />)}</section><aside className="side-stack"><section className="panel briefing-card"><div className="panel-heading"><span>CASE BRIEFING</span><FileText size={16} /></div><div className="briefing-seal">L7</div><h3>An archive that should have stayed closed.</h3><p>A collection of old files, strange messages, and one unfinished investigation. The truth is in the details.</p><div className="rule" /><span className="micro-label">CLASSIFICATION</span><strong>FICTIONAL / SCHOOL EVENT</strong></section><section className="panel"><div className="panel-heading"><span>FILE CATEGORIES</span><SlidersHorizontal size={16} /></div>{['Correspondence', 'Photographs', 'Audio signals', 'Newspaper reports'].map((category, index) => <div className="category-row" key={category}><span className={`category-dot dot-${index}`} /><span>{category}</span><small>{[2, 4, 1, 3][index]} files</small></div>)}</section></aside></div></>;
}

function StageCard({ stage, compact = false }: { stage: Stage; compact?: boolean }) {
  const isActionable = stage.state === 'available';
  return <article className={`stage-card ${stage.state} ${compact ? 'compact' : ''}`}><div className="stage-card-top"><span className="stage-index">0{stage.number}</span><span className={`status-pill ${stage.state}`}>{stage.state}</span></div><div className="stage-card-content"><div><h3>{stage.title}</h3><p>{stage.subtitle}</p></div>{!compact && <div className="stage-date"><Clock3 size={13} /> {stage.date}</div>}</div>{!compact && <div className="stage-card-bottom"><div className="progress-line"><span style={{ width: `${stage.progress}%` }} /></div><span>{stage.progress}%</span>{isActionable && <button className="icon-button bordered" onClick={() => navigate('/evidence/CAS-017')} aria-label="Open stage"><ArrowRight size={15} /></button>}</div>}</article>;
}

function EvidenceRoom() {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All files');
  const filtered = useMemo(() => evidence.filter((item) => `${item.title} ${item.category} ${item.id}`.toLowerCase().includes(query.toLowerCase()) && (filter === 'All files' || item.category === filter)), [query, filter]);
  return <><PageHeader eyebrow="Archive / Evidence room" title="Evidence room" description="Every document is a signal. Search the archive by title, source, or case identifier." action={<button className="button button-secondary demo-disabled" disabled title="Advanced filters are unavailable in demo mode"><SlidersHorizontal size={16} /> Filters unavailable</button>} /><DemoNotice /><div className="toolbar"><div className="search-box"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search evidence, IDs, or keywords" aria-label="Search evidence" /></div><div className="filter-tabs">{['All files', 'Document', 'Interview', 'Audio'].map((option) => <button key={option} className={filter === option ? 'active' : ''} onClick={() => setFilter(option)}>{option}</button>)}</div><button className="icon-button bordered demo-disabled" disabled aria-label="More evidence options unavailable in demo mode" title="More evidence options are unavailable in demo mode"><MoreHorizontal size={18} /></button></div><div className="evidence-list">{filtered.map((item) => <EvidenceRow key={item.id} item={item} />)}{filtered.length === 0 && <div className="empty-state"><Search size={24} /><h3>No files found</h3><p>Try a different search term or category.</p></div>}</div></>;
}

function EvidenceRow({ item }: { item: EvidenceItem }) {
  const canOpen = item.status !== 'locked';
  return <button className={`evidence-row ${item.status}`} onClick={() => canOpen && navigate(`/evidence/${item.id}`)} disabled={!canOpen}><div className={`evidence-thumb ${item.category.toLowerCase().replace(' ', '-')}`}><FileText size={22} /></div><div className="evidence-main"><div className="evidence-title"><span>{item.id}</span><h3>{item.title}</h3></div><p>{item.summary}</p><div className="evidence-meta"><span>{item.category}</span><span>{item.source}</span><span>{item.date}</span></div></div><div className="evidence-aside"><span className={`status-pill ${item.status}`}>{item.status === 'locked' ? <><Lock size={11} /> Locked</> : item.classification}</span>{canOpen ? <ArrowRight size={16} /> : <Lock size={16} />}</div></button>;
}

function EvidenceViewer({ id }: { id: string }) {
  const item = evidence.find((entry) => entry.id === id) ?? evidence[2];
  return <><button className="back-link" onClick={() => navigate('/evidence')}><ArrowLeft size={15} /> Back to evidence room</button><div className="viewer-heading"><div><div className="eyebrow">{item.id} / {item.category}</div><h1>{item.title}</h1><p>Source: {item.source} <span className="muted-separator">•</span> {item.date}</p></div><span className="evidence-stamp">ARCHIVE COPY</span></div><div className="viewer-layout"><article className="document-surface"><div className="document-top"><span>THE LAST SIGNAL</span><span>FILE {item.id}</span></div><div className="document-content"><div className="document-classification">FICTIONAL SCHOOL MYSTERY / EVIDENCE RECORD</div><h2>{item.title}</h2><div className="document-rule" /><p className="document-lead">{item.summary}</p><p>When the case was first catalogued, the record was marked for review. The original context remains incomplete, and several details have been redacted pending the next stage of the investigation.</p><div className="redaction redaction-short" /><p>“The details that seem incidental are often the only parts that survive.”</p><div className="document-note"><span>FIELD NOTE / 03</span><p>Compare this file with the witness testimony. Do not treat the current classification as a final conclusion.</p></div><div className="redaction redaction-long" /><p>Additional media and verified case attachments will appear here when supplied by the event team.</p></div><div className="document-footer"><span>CASE 07 / ARCHIVE</span><span>PAGE 01 / 01</span></div></article><aside className="viewer-aside"><section className="panel metadata-panel"><div className="panel-heading"><span>FILE METADATA</span><Archive size={16} /></div><Meta label="Classification" value={item.classification} /><Meta label="Status" value={item.status} /><Meta label="Source" value={item.source} /><Meta label="Identifier" value={item.id} /></section>{item.category === 'Audio' ? <AudioPlaceholder /> : <section className="panel related-panel"><div className="panel-heading"><span>RELATED EVIDENCE</span><ArrowRight size={16} /></div><button className="related-item" onClick={() => navigate('/evidence/CAS-017')}><span className="related-icon"><FileText size={14} /></span><span><strong>CAS-017</strong><small>Witness testimony</small></span><ArrowRight size={14} /></button><button className="related-item demo-disabled" disabled aria-label="MAP-004 locked evidence" title="This evidence remains locked in demo mode"><span className="related-icon"><Map size={14} /></span><span><strong>MAP-004</strong><small>Photograph coordinates</small></span><Lock size={14} /></button></section>}</aside></div></>;
}

function Meta({ label, value }: { label: string; value: string }) { return <div className="meta-row"><span>{label}</span><strong>{value}</strong></div>; }
function AudioPlaceholder() { return <section className="panel audio-panel"><div className="panel-heading"><span>AUDIO PLAYER</span><Headphones size={16} /></div><div className="audio-placeholder"><div className="audio-play" role="img" aria-label="Audio playback unavailable in demo mode" title="Audio playback unavailable in demo mode"><Play size={18} fill="currentColor" /></div><div className="waveform">{Array.from({ length: 24 }).map((_, index) => <span key={index} style={{ height: `${20 + ((index * 17) % 52)}%` }} />)}</div><div className="audio-time">00:00 / 00:00</div><div className="audio-controls"><Volume2 size={15} /><span>1×</span></div></div><p className="muted-note">Audio asset not supplied. Playback is unavailable in demo mode.</p></section>; }

function SignalMap() {
  const locations = ['Lake Herman Road', 'Blue Rock Springs Park', 'Lake Berryessa', 'Washington & Cherry'];
  return <><PageHeader eyebrow="Investigation / Signal map" title="The signal map" description="Four locations. One choice. The map is a story surface only until the case rules are verified." /><DemoNotice>Location selection is intentionally disabled. No physical visits are part of this online-only fictional game.</DemoNotice><div className="map-layout"><section className="map-board"><div className="map-grid-lines" /><div className="map-label map-label-a">NORTH BAY</div><div className="map-label map-label-b">PRESIDIO HEIGHTS</div>{locations.map((location, index) => <div key={location} className={`map-pin pin-${index}`}><span>{String(index + 1).padStart(2, '0')}</span><div><strong>{location}</strong><small>LOCATION {String(index + 1).padStart(2, '0')}</small></div></div>)}<div className="map-compass">N<br /><span>✦</span><br />S</div><div className="map-water">FICTIONAL CASE MAP<br /><small>NOT FOR NAVIGATION</small></div></section><aside className="panel map-side"><div className="panel-heading"><span>LOCATION FILES</span><Map size={16} /></div><p className="map-intro">The witness file points to a location hidden in the archive. Review the evidence before any selection is enabled.</p>{locations.map((location, index) => <div className="location-row" key={location}><span className="location-number">0{index + 1}</span><div><strong>{location}</strong><small>Coordinates pending verification</small></div><Lock size={14} /></div>)}<button className="button button-disabled" disabled><Lock size={15} /> Selection unavailable</button></aside></div></>;
}

function Messages() { return <><PageHeader eyebrow="Communications / One-way archive" title="Messages" description="Signals received during the investigation. Replies are not available in this visual shell." action={<button className="button button-secondary demo-disabled" disabled title="Notification settings are unavailable in demo mode"><Bell size={16} /> Notifications unavailable</button>} /><DemoNotice>Message content is safe placeholder material until the event team approves the final copy.</DemoNotice><div className="messages-layout"><div className="message-feed">{messages.map((message) => <div key={`${message.sender}-${message.time}`} className={`full-message ${message.tone}`}><div className="full-message-head"><div className={`message-avatar ${message.tone}`}>{message.tone === 'system' ? <Radio size={13} /> : message.tone === 'director' ? 'D' : '?'}</div><div><strong>{message.sender}</strong><time>{message.time} / ARCHIVE TIME</time></div></div><p>{message.text}</p></div>)}</div><aside className="panel comms-note"><Radio size={20} /><h3>Keep the channel open.</h3><p>New messages will appear here as the case progresses. This channel is one-way for the first pass.</p></aside></div></>; }

function Progress() { return <><PageHeader eyebrow="Investigation / Seven stages" title="Case progress" description="A shared view of what has been cleared, what is active, and what remains sealed." /><DemoNotice /><div className="progress-summary"><div className="panel summary-card"><span className="eyebrow">TOTAL COMPLETION</span><strong>28<span>%</span></strong><div className="progress-line"><span style={{ width: '28%' }} /></div><small>2 of 7 stages cleared</small></div><div className="panel summary-card"><span className="eyebrow">CURRENT WINDOW</span><strong>31<span>h</span> 42<span>m</span></strong><small>Stage 3 closes 27 Oct 2026 / 17:00</small></div><div className="panel summary-card"><span className="eyebrow">TEAM STATUS</span><strong>04<span>/ 04</span></strong><small>All investigators connected</small></div></div><div className="progress-list">{stages.map((stage) => <StageCard key={stage.number} stage={stage} />)}</div></>; }

function Leaderboard() { return <><PageHeader eyebrow="Community / Demo standings" title="Leaderboard" description="A friendly view of progress for the school event. Rankings are not connected yet." /><DemoNotice>These names and scores are illustrative only. Authoritative scoring will come from the verified backend.</DemoNotice><div className="leaderboard-tabs"><button className="active" type="button">Teams</button><button className="demo-disabled" type="button" disabled title="Individual standings are unavailable in demo mode">Individuals unavailable</button><span className="visibility"><Users size={15} /> Demo visibility</span></div><div className="leaderboard-list"><div className="leaderboard-head"><span>RANK</span><span>TEAM</span><span>STAGES</span><span>STATUS</span></div>{[['01', 'The Redacted Files', '3 / 7', 'Active'], ['02', 'North Star', '2 / 7', 'Active'], ['03', 'The Night Editors', '2 / 7', 'Active'], ['04', 'Case Closed?', '1 / 7', 'Started']].map(([rank, name, score, status]) => <div className="leaderboard-row" key={rank}><span className="rank">{rank}</span><strong>{name}</strong><span>{score}</span><span className="leader-status"><span className="live-dot" /> {status}</span></div>)}</div></>; }

function Team() { return <><PageHeader eyebrow="Workspace / Shared investigation" title="Your team" description="Your progress is shared with the investigators assigned to this case." action={<button className="button button-secondary demo-disabled" disabled title="Invites are unavailable in demo mode"><Users size={16} /> Invites unavailable</button>} /><DemoNotice>Creating, joining, and leaving teams are disabled until the verified backend is connected.</DemoNotice><div className="team-layout"><section className="panel team-card"><div className="team-card-head"><div className="team-emblem">RF</div><div><span className="eyebrow">TEAM 04 / DEMO</span><h2>The Redacted Files</h2><p>Established 19 October 2026</p></div><button className="icon-button bordered demo-disabled" disabled aria-label="Team options unavailable in demo mode" title="Team options are unavailable in demo mode"><MoreHorizontal size={18} /></button></div><div className="rule" /><div className="team-members">{[['JD', 'Jordan Doe', 'Lead investigator'], ['MR', 'Maya R.', 'Research'], ['AL', 'Alex L.', 'Archive'], ['SK', 'Sam K.', 'Analysis']].map(([initials, name, role]) => <div className="member-row" key={initials}><span className="avatar">{initials}</span><div><strong>{name}</strong><small>{role}</small></div><span className="member-state">Demo member</span></div>)}</div></section><aside className="panel shared-progress"><div className="panel-heading"><span>SHARED PROGRESS</span><Gauge size={16} /></div><div className="circle-progress"><strong>28</strong><span>%</span></div><p>Everyone on your team sees the same cleared stages and evidence access.</p><button className="text-button" onClick={() => navigate('/progress')}>View progress <ArrowRight size={15} /></button></aside></div></>; }

function Account() {
  const [displayName, setDisplayName] = useState('Jordan Doe');
  const [school, setSchool] = useState('Northbridge School');
  const [feedback, setFeedback] = useState('');

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    if (displayName.trim().length < 2) {
      setFeedback('Enter a display name with at least 2 characters.');
      return;
    }
    if (school.trim().length < 2) {
      setFeedback('Enter a school or group name with at least 2 characters.');
      return;
    }
    setFeedback('Preview updated locally. Nothing was sent to a server.');
  };

  return <><PageHeader eyebrow="Workspace / Personal settings" title="Account" description="Manage your display details and safety preferences for the investigation." /><DemoNotice>Profile changes are preview-only until authentication and the verified backend are connected.</DemoNotice><div className="settings-layout"><form className="panel settings-card" onSubmit={handleSubmit}><div className="panel-heading"><span>PROFILE DETAILS</span><UserRound size={16} /></div><label>Display name<input value={displayName} onChange={(event) => setDisplayName(event.target.value)} minLength={2} maxLength={40} required /></label><label>School or group<input value={school} onChange={(event) => setSchool(event.target.value)} minLength={2} maxLength={80} required /></label><label>Access code<input value="Not connected" readOnly aria-describedby="account-access-note" /></label><button className="button button-primary" type="submit">Save local preview</button>{feedback && <p className="form-feedback" role="status">{feedback}</p>}<p id="account-access-note" className="muted-note">Sign-in and sign-out will be added after the backend contract is verified.</p></form><section className="panel settings-card"><div className="panel-heading"><span>SAFETY &amp; ACCESSIBILITY</span><ShieldAlert size={16} /></div><div className="setting-toggle"><div><strong>Reduced scare mode</strong><p>Will apply when approved media is connected.</p></div><span className="toggle disabled" /></div><div className="setting-toggle"><div><strong>Mute audio by default</strong><p>Audio never plays automatically in this game.</p></div><span className="toggle on" /></div><div className="setting-toggle"><div><strong>Safety &amp; debrief access</strong><p>Always available from the navigation.</p></div><span className="toggle on" /></div></section></div></>;
}

function Admin() { const sections = ['Overview', 'Content & messages', 'Schedule', 'Stages & challenges', 'Participants & teams', 'Score adjustments', 'Account controls', 'Ending controls', 'Settings']; return <><PageHeader eyebrow="Workspace / Restricted view" title="Admin shell" description="A visual planning surface for event staff. No privileged actions are available here." action={<span className="status-pill restricted"><Lock size={11} /> Server-authorised only</span>} /><DemoNotice>Admin controls are intentionally non-functional. Every sensitive action must be authorized by the verified backend.</DemoNotice><div className="admin-layout"><aside className="panel admin-nav"><div className="panel-heading"><span>CONTROL ROOM</span><Settings size={16} /></div>{sections.map((section, index) => <button className={`${index === 0 ? 'active' : ''} ${index > 0 ? 'demo-disabled' : ''}`} disabled={index > 0} key={section}>{section}{index > 0 && <Lock size={13} />}</button>)}</aside><section className="admin-overview"><div className="admin-cards">{[['ACTIVE PLAYERS', '—', 'Waiting for connection'], ['STAGE WINDOW', '03', 'Current stage'], ['OPEN SIGNALS', '02', 'Needs review']].map(([label, value, note]) => <div className="panel admin-stat" key={label}><span className="eyebrow">{label}</span><strong>{value}</strong><small>{note}</small></div>)}</div><section className="panel admin-table"><div className="panel-heading"><span>EVENT HEALTH</span><span className="status-pill restricted">READ ONLY</span></div>{['Content review', 'Schedule configuration', 'Media assets', 'Participant access'].map((item) => <div className="health-row" key={item}><span className="health-check"><Check size={13} /></span><strong>{item}</strong><span>Not connected</span><Lock size={14} /></div>)}</section></section></div></>; }

export default App;
