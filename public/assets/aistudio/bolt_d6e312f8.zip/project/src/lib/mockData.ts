export type EvidenceStatus = 'available' | 'locked' | 'reviewed' | 'restricted';

export type EvidenceItem = {
  id: string;
  title: string;
  category: string;
  source: string;
  date: string;
  classification: string;
  status: EvidenceStatus;
  summary: string;
};

export type Stage = {
  number: number;
  title: string;
  subtitle: string;
  state: 'completed' | 'available' | 'locked' | 'late';
  date: string;
  progress: number;
};

export const navItems = [
  { label: 'Dashboard', path: '/dashboard', icon: 'layout' },
  { label: 'Investigation', path: '/investigation', icon: 'folder' },
  { label: 'Evidence room', path: '/evidence', icon: 'file' },
  { label: 'Signal map', path: '/map', icon: 'map' },
  { label: 'Messages', path: '/messages', icon: 'message' },
  { label: 'Progress', path: '/progress', icon: 'activity' },
  { label: 'Leaderboard', path: '/leaderboard', icon: 'bar' },
  { label: 'Team', path: '/team', icon: 'users' },
];

export const stages: Stage[] = [
  { number: 1, title: 'The archive', subtitle: "The archivist's letter", state: 'completed', date: 'Oct 19–21', progress: 100 },
  { number: 2, title: 'The locked files', subtitle: 'Coordinates', state: 'completed', date: 'Oct 21–23', progress: 100 },
  { number: 3, title: 'The witness', subtitle: 'Testimony and the map', state: 'available', date: 'Oct 23–25', progress: 64 },
  { number: 4, title: 'The reversed audio', subtitle: 'The suspicious call', state: 'locked', date: 'Oct 25–27', progress: 0 },
  { number: 5, title: 'The newspaper', subtitle: 'Suspect database', state: 'locked', date: 'Oct 27–29', progress: 0 },
  { number: 6, title: "Ellen Vale's journal", subtitle: 'The final review', state: 'locked', date: 'Oct 29–31', progress: 0 },
  { number: 7, title: 'The final article', subtitle: 'The last signal', state: 'locked', date: 'Oct 31–Nov 2', progress: 0 },
];

export const evidence: EvidenceItem[] = [
  { id: 'ARC-001', title: 'The Archivist’s Letter', category: 'Correspondence', source: 'Case archive', date: '19 Oct 2026', classification: 'Open file', status: 'reviewed', summary: 'A letter found folded inside the first archive box. Its margins carry a sequence of unusual marks.' },
  { id: 'ARC-002', title: 'Password Sheet', category: 'Document', source: 'Unknown', date: '19 Oct 2026', classification: 'Open file', status: 'reviewed', summary: 'A sheet of partial credentials with several lines obscured by ink.' },
  { id: 'CAS-017', title: 'Witness Testimony', category: 'Interview', source: 'Case file 017', date: '21 Oct 2026', classification: 'Inconclusive', status: 'available', summary: 'A recollection of a sound, a closing door, and a light moving across the street.' },
  { id: 'MAP-004', title: 'Photograph Coordinates', category: 'Image', source: 'Locked documents', date: '21 Oct 2026', classification: 'Restricted', status: 'locked', summary: 'Four photographs. Each contains a date, a time, and a location encoded in the margins.' },
  { id: 'MSG-013', title: 'The Suspicious Call', category: 'Audio', source: 'Incoming signal', date: '23 Oct 2026', classification: 'Audio pending', status: 'locked', summary: 'A future audio artifact. The original media has not been supplied for this shell.' },
  { id: 'NEWS-002', title: 'The San Francisco Chronicle', category: 'Newspaper', source: 'Public record', date: '23 Oct 2026', classification: 'Demo article', status: 'available', summary: 'A report about an archive recovered near the Presidio and an anonymous message.' },
];

export const messages = [
  { sender: 'SYSTEM', tone: 'system', time: '09:00', text: 'Stage 3 is now available. Your case window is active.' },
  { sender: 'THE DIRECTOR', tone: 'director', time: '08:12', text: 'The witness file is ready for review. Read slowly. The gaps matter as much as the words.' },
  { sender: 'SYSTEM', tone: 'system', time: 'Yesterday', text: 'Archive access recorded for CASE-017.' },
  { sender: 'UNKNOWN SIGNAL', tone: 'antagonist', time: 'Oct 21', text: 'You are looking at the wrong person.' },
];
